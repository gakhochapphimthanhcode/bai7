# Bài tập 07 – Trang giới thiệu bản thân

## Cấu trúc thư mục
- `index.html`: Nội dung trang web.
- `style.css`: Định dạng giao diện.
- `images/avatar.jpg`: Ảnh đại diện (bạn tự thêm ảnh vào thư mục này).

## Cách chạy
1. Giải nén thư mục.
2. Mở `index.html` bằng trình duyệt hoặc mở thư mục bằng VS Code.
3. Có thể cài tiện ích Live Server trong VS Code và chọn **Open with Live Server**.

## Nội dung cần cá nhân hóa trước khi nộp
- Thay `[HỌ VÀ TÊN]`, `[TÊN NGÀNH]`, `[TÊN TRƯỜNG]`.
- Thêm ảnh của bạn và đặt tên file là `avatar.jpg` trong thư mục `images`.
- Chỉnh sở thích và thời khóa biểu theo thông tin thực tế.
- Thay liên kết Facebook/GitHub mẫu bằng đường dẫn tài khoản của bạn.

## Đưa source code lên GitHub
1. Đăng nhập GitHub và tạo repository mới, ví dụ `bai-tap-07-gioi-thieu-ban-than`.
2. Chọn repository ở chế độ Public nếu giáo viên cần mở xem.
3. Chọn **Add file → Upload files**, tải lên `index.html`, `style.css`, `README.md` và thư mục `images` có ảnh đại diện.
4. Nhấn **Commit changes**.
5. Sao chép URL repository để nộp cho giáo viên.

## Xuất bản trang web (không bắt buộc nếu giáo viên chỉ yêu cầu source code)
Trong repository, vào **Settings → Pages**. Chọn nhánh `main`, thư mục `/ (root)`, nhấn **Save**. Sau khi GitHub Pages triển khai xong, trang web sẽ có đường dẫn dạng `https://ten-tai-khoan.github.io/ten-repository/`.
